from shipping import fee


def test_fee_lower_boundary_returns_integer_fee():
    result = fee(0)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 1000
