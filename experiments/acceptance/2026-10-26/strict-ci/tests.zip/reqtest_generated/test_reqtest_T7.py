import pytest
from shipping import fee


def test_bool_amount_raises_type_error():
    with pytest.raises(TypeError):
        fee(True)
