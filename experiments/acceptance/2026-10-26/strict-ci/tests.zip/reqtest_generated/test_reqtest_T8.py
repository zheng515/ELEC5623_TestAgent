import pytest
from shipping import fee


def test_string_amount_raises_type_error():
    with pytest.raises(TypeError):
        fee("100")
