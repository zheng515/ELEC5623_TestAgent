from shipping import fee


def test_fee_standard_amount_returns_integer_fee():
    result = fee(500)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 1000
