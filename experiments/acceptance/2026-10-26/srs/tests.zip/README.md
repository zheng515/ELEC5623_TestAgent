# Generated requirement tests

Extract this archive at the root of the original project, so reqtest_generated sits beside the source files.
Use the exact source version below. Install your project dependencies and the test runner in your development environment.

Source: Synthetic threshold defect; not saved to user history
Project directory within the original repository/archive: (root)
Source SHA-256: f06c7fedcfc228ac1a3df1d98c35a51526a75c02f93a8efd77462bc6bad8f365
Runtime: Python 3.11 / pytest 8.4.2
Approved generated test files: 7

Run from the project root:

```sh
python -m pytest reqtest_generated
```

Saved workflow status: completed
Recorded latest execution: 6 passed, 1 failed, 0 errors.
Review verification.json for original requirement sources, test reviews, setup information, diagnoses and execution logs.

This archive does not include the implementation, dependency installation, disposable services or Docker images.
Replicate the saved environment and services if the tests require them. A failing assertion can indicate an implementation defect; do not change the expected result merely to make it pass.
Passing recorded cases does not establish exhaustive requirement coverage or correctness.
