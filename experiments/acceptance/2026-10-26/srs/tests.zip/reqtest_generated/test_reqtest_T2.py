import shipping


def test_fee_returns_1000_for_zero():
    result = shipping.fee(0)
    assert isinstance(result, int)
    assert result == 1000
