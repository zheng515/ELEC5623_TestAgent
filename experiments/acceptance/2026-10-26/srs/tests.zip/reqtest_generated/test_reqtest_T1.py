import shipping


def test_fee_returns_1000_for_typical_in_range_amount():
    result = shipping.fee(5000)
    assert isinstance(result, int)
    assert result == 1000
