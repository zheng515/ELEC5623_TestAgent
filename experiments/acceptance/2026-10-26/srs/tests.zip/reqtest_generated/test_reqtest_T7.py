import pytest
import shipping


def test_fee_raises_type_error_for_bool_and_other_non_builtin_int():
    with pytest.raises(TypeError):
        shipping.fee(True)
    with pytest.raises(TypeError):
        shipping.fee(1.5)
