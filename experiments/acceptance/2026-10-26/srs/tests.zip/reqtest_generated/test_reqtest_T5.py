import shipping


def test_fee_returns_zero_at_10000():
    result = shipping.fee(10000)
    assert isinstance(result, int)
    assert result == 0
