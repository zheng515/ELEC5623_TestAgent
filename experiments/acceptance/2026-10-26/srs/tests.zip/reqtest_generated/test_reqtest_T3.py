import shipping


def test_fee_returns_1000_for_9999():
    result = shipping.fee(9999)
    assert isinstance(result, int)
    assert result == 1000
