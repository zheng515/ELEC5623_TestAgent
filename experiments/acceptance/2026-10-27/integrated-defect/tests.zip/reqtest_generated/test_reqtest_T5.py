import pytest
import shipping


def test_fee_raises_type_error_for_non_builtin_int():
    for amount_cents in (True, 1.5):
        with pytest.raises(TypeError):
            shipping.fee(amount_cents)
