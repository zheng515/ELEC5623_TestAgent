import shipping


def test_fee_returns_zero_above_10000():
    result = shipping.fee(10001)
    assert isinstance(result, int)
    assert not isinstance(result, bool)
    assert result == 0
