import shipping


def test_fee_returns_1000_for_amounts_0_through_9999():
    for amount_cents in (0, 5000, 9999):
        result = shipping.fee(amount_cents)
        assert isinstance(result, int)
        assert not isinstance(result, bool)
        assert result == 1000
