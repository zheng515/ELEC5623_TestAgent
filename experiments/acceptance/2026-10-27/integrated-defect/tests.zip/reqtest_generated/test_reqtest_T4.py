import pytest
import shipping


def test_fee_raises_value_error_for_negative_integer():
    with pytest.raises(ValueError):
        shipping.fee(-1)
