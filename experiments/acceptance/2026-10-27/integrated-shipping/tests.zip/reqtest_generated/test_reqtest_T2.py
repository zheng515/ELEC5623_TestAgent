from shipping import fee


def test_fee_zero_returns_integer_1000():
    result = fee(0)
    assert isinstance(result, int)
    assert not isinstance(result, bool)
    assert result == 1000