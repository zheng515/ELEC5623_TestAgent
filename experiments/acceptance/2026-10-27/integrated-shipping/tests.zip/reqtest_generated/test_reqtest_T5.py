from shipping import fee


def test_fee_10001_returns_integer_zero():
    result = fee(10001)
    assert isinstance(result, int)
    assert not isinstance(result, bool)
    assert result == 0