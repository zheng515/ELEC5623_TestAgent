from shipping import fee


def test_fee_500_returns_integer_1000():
    result = fee(500)
    assert isinstance(result, int)
    assert not isinstance(result, bool)
    assert result == 1000