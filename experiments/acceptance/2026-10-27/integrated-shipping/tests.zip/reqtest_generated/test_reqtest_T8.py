import pytest
from shipping import fee


def test_float_fee_input_raises_type_error():
    with pytest.raises(TypeError):
        fee(1.0)