import pytest
from shipping import fee


def test_bool_fee_input_raises_type_error():
    with pytest.raises(TypeError):
        fee(True)