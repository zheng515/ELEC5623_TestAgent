from shipping import fee


def test_fee_10000_returns_integer_zero():
    result = fee(10000)
    assert isinstance(result, int)
    assert not isinstance(result, bool)
    assert result == 0