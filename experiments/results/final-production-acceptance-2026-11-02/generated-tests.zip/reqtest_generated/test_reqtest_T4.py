import pytest
from inventory import remaining


def test_negative_stock_or_request_raises_value_error():
    with pytest.raises(ValueError):
        remaining(-1, 0)
    with pytest.raises(ValueError):
        remaining(0, -1)
