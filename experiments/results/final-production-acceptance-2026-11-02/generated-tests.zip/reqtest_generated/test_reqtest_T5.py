import pytest
from inventory import remaining


def test_non_builtin_int_and_bool_arguments_raise_type_error():
    class IntSubclass(int):
        pass

    cases = [
        (IntSubclass(4), 1),
        (4, IntSubclass(1)),
        (True, 0),
        (4, False),
    ]
    for stock, requested in cases:
        with pytest.raises(TypeError):
            remaining(stock, requested)
