from inventory import remaining


def test_equal_stock_returns_integer_zero():
    result = remaining(5, 5)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 0
