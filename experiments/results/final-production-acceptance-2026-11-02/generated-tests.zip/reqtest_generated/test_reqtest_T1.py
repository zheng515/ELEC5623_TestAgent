from inventory import remaining


def test_below_stock_returns_integer_difference():
    result = remaining(10, 3)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 7
