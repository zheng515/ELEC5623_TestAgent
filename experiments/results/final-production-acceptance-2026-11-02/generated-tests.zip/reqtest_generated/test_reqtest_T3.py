import pytest
from inventory import remaining


def test_request_above_stock_raises_value_error():
    with pytest.raises(ValueError):
        remaining(4, 5)
