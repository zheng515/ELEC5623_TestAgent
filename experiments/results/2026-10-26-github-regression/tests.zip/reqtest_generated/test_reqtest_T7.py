import pytest
from shipping import fee


def test_true_raises_type_error():
    with pytest.raises(TypeError):
        fee(True)
