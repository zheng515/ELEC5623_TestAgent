from shipping import fee


def test_fee_above_10000_returns_integer_zero():
    result = fee(10001)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 0
