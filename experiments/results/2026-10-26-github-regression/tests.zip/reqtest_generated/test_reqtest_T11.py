import pytest
from shipping import fee


def test_none_raises_type_error():
    with pytest.raises(TypeError):
        fee(None)
