import pytest
from shipping import fee


def test_false_raises_type_error():
    with pytest.raises(TypeError):
        fee(False)
