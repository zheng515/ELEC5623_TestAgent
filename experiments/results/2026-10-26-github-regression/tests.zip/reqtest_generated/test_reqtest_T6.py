import pytest
from shipping import fee


def test_negative_amount_raises_value_error():
    with pytest.raises(ValueError):
        fee(-1)
