from shipping import fee


def test_fee_at_9999_returns_integer_1000():
    result = fee(9999)
    assert isinstance(result, int) and not isinstance(result, bool)
    assert result == 1000
