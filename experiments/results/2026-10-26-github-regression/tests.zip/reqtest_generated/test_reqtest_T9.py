import pytest
from shipping import fee


def test_float_raises_type_error():
    with pytest.raises(TypeError):
        fee(1.5)
