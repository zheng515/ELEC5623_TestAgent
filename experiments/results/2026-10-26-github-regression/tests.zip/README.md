# Generated requirement tests

Extract this archive at the root of the original project, so reqtest_generated sits beside the source files.
Use the exact source version below. Install your project dependencies and the test runner in your development environment.

Source: examples/experiments/github-demo/project
Project directory within the original repository/archive: (root)
Source SHA-256: 5721f21c6f78655415c0b29e1ad76d2981c14c68d65ff23e7ef0172759432a24
Runtime: Python 3.11 / pytest 8.4.2
Approved generated test files: 11

Run from the project root:

```sh
python -m pytest reqtest_generated
```

Saved workflow status: completed
Recorded latest execution: 10 passed, 1 failed, 0 errors.
Review verification.json for original requirement sources, test reviews, setup information, diagnoses and execution logs.

This archive does not include the implementation, dependency installation, disposable services or Docker images.
Replicate the saved environment and services if the tests require them. A failing assertion can indicate an implementation defect; do not change the expected result merely to make it pass.
Passing recorded cases does not establish exhaustive requirement coverage or correctness.
