from shipping import fee


def test_fee_at_and_above_threshold_returns_integer_zero():
    for amount_cents in (10000, 10001):
        result = fee(amount_cents)
        assert isinstance(result, int)
        assert not isinstance(result, bool)
        assert result == 0