from shipping import fee


def test_fee_below_threshold_returns_integer_1000():
    for amount_cents in (0, 9999, 500):
        result = fee(amount_cents)
        assert isinstance(result, int)
        assert not isinstance(result, bool)
        assert result == 1000