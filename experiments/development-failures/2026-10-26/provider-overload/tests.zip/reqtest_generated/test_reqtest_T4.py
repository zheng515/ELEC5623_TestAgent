from shipping import fee


def test_non_builtin_int_arguments_raise_type_error():
    for amount_cents in (True, "500"):
        try:
            fee(amount_cents)
        except TypeError:
            pass
        else:
            raise AssertionError(f"fee({amount_cents!r}) did not raise TypeError")