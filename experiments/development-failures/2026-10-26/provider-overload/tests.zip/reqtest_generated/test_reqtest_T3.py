from shipping import fee


def test_negative_amount_raises_value_error():
    try:
        fee(-1)
    except ValueError:
        pass
    else:
        raise AssertionError("fee(-1) did not raise ValueError")