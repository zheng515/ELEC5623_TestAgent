# Generated requirement tests

Extract this archive at the root of the original project, so reqtest_generated sits beside the source files.
Use the exact source version below. Install your project dependencies and the test runner in your development environment.

Source: examples/shipping
Project directory within the original repository/archive: (root)
Source SHA-256: 1cb700c032c7fef64e8fc6bb618b829a8c61237d0de721c52fa71291c58569fe
Runtime: Python 3.11 / pytest 8.4.2
Approved generated test files: 4

Run from the project root:

```sh
python -m pytest --deselect=tests/test_shipping.py -- tests/test_shipping.py reqtest_generated
```

Representative original test modules are collected for their saved directory setup, then their test functions are deselected. Only generated test functions execute. Collection hooks and module import effects remain part of raw outcomes. Their helper files and conftest configuration must remain available in the original project.

Saved workflow status: failed
Recorded latest execution: 5 passed, 0 failed, 0 errors.
Review report.json for original requirement sources, test reviews, setup information, diagnoses and execution logs.

This archive does not include the implementation, dependency installation, disposable services or Docker images.
Replicate the saved environment and services if the tests require them. A failing assertion can indicate an implementation defect; do not change the expected result merely to make it pass.
Passing recorded cases does not establish exhaustive requirement coverage or correctness.
